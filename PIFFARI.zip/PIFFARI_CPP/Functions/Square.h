#ifndef SQUARE_H_
#define SQUARE_H_

class Square{
public:
    int operator() (int element);
};

#endif /*SQUARE_H_*/
