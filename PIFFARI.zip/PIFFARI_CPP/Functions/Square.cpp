#include "Square.h"

int Square::operator() (int element){
    return element*element;
}

