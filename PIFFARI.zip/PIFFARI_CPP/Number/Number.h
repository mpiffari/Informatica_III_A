#ifndef NUMBER_H_
#define NUMBER_H_

// Base class for this library
class Number{
public:
    Number(); // Default constructor
	virtual ~Number(); // Default destructor
};

#endif /*NUMBER_H_*/
