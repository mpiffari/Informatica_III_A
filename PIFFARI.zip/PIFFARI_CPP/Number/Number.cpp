#include "Number.h"
#include <sstream>
#include <iostream>

using namespace std;

Number::Number(){
}

Number::~Number(){
	cout<<"Deleted number"<<endl;
}
