package Drinks

// Trait (like Java interface) definition
trait Expirable {
  def isExpired(): Boolean
}